// Dashboard Page JavaScript
// FSD-1 Syllabus: Data Processing, DOM Manipulation, LocalStorage

document.addEventListener('DOMContentLoaded', function() {
    // Initialize managers
    const studyManager = new StudySessions();
    const focusTracker = new FocusTracker();
    
    // DOM Elements
    const totalSessionsElement = document.getElementById('totalSessions');
    const totalFocusTimeElement = document.getElementById('totalFocusTime');
    const totalSubjectsElement = document.getElementById('totalSubjects');
    const recentActivityElement = document.getElementById('recentActivity');
    const noActivityMessage = document.getElementById('noActivityMessage');
    const chartBars = document.querySelectorAll('.chart-bar');
    
    // Load dashboard data
    loadDashboardData();
    loadRecentActivity();
    loadWeeklyChart();
    loadSubjectChart();
    loadWeeklyReport();
    

    // Dark Mode Toggle
    const darkModeToggle = document.getElementById('darkModeToggle');
    const body = document.body;

    // Check local storage for preference
    if (localStorage.getItem('darkMode') === 'enabled') {
        body.classList.add('dark-mode');
        if (darkModeToggle) darkModeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    }

    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', () => {
            body.classList.toggle('dark-mode');
            if (body.classList.contains('dark-mode')) {
                localStorage.setItem('darkMode', 'enabled');
                darkModeToggle.innerHTML = '<i class="fas fa-sun"></i>';
            } else {
                localStorage.setItem('darkMode', 'disabled');
                darkModeToggle.innerHTML = '<i class="fas fa-moon"></i>';
            }
        });
    }

    // Auto-refresh every 30 seconds
    setInterval(() => {
        loadDashboardData();
        loadSubjectChart();
        loadWeeklyReport();
    }, 30000);
    
    // Load Dashboard Data
    function loadDashboardData() {
        // 1. Total Study Sessions
        const totalSessions = studyManager.getTotalSessions();
        totalSessionsElement.textContent = totalSessions;
        
        // 2. Total Focus Time
        const totalFocusSeconds = focusTracker.getTotalFocusTime();
        const formattedTime = FocusTracker.formatTime(totalFocusSeconds).formatted;
        totalFocusTimeElement.textContent = formattedTime;
        
        // 3. Unique Subjects
        const uniqueSubjects = studyManager.getUniqueSubjects();
        totalSubjectsElement.textContent = uniqueSubjects.length;
    }
    
    // Load Recent Activity
    function loadRecentActivity() {
        const sessions = studyManager.getAllSessions();
        
        // Clear current activity
        recentActivityElement.innerHTML = '';
        
        if (sessions.length === 0) {
            recentActivityElement.appendChild(noActivityMessage.cloneNode(true));
            return;
        }
        
        // Sort by date (newest first) and take first 5
        const recentSessions = sessions
            .sort((a, b) => new Date(b.date) - new Date(a.date))
            .slice(0, 5);
        
        // Create table rows
        recentSessions.forEach(session => {
            const row = createActivityRow(session);
            recentActivityElement.appendChild(row);
        });
    }
    
    // Create Activity Table Row
    function createActivityRow(session) {
        const row = document.createElement('tr');
        
        // Format date
        const formattedDate = formatDate(session.date);
        
        // Format time
        const formattedTime = `${formatTime(session.startTime)} - ${formatTime(session.endTime)}`;
        
        // Determine status based on date
        const sessionDate = new Date(session.date);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        let status = '';
        let statusClass = '';
        
        if (session.status === 'completed') {
            status = 'Completed';
            statusClass = 'badge bg-success';
        } else if (sessionDate < today) {
            status = 'Completed';
            statusClass = 'badge bg-success';
        } else if (sessionDate.toDateString() === today.toDateString()) {
            status = 'Today';
            statusClass = 'badge bg-primary';
        } else {
            status = 'Upcoming';
            statusClass = 'badge bg-warning';
        }
        
        row.innerHTML = `
            <td>
                <strong>${session.subject}</strong>
                ${session.notes ? `<br><small class="text-muted">${session.notes}</small>` : ''}
            </td>
            <td>${formattedDate}</td>
            <td>${formattedTime}</td>
            <td><span class="${statusClass}">${status}</span></td>
        `;
        
        return row;
    }
    
    // Load Weekly Chart
    function loadWeeklyChart() {
        // This is a simplified version - in a real app, you would track daily focus time
        // For demo purposes, we'll generate some random data
        
        // Clear existing heights
        chartBars.forEach(bar => {
            bar.style.height = '0%';
        });
        
        // Get today's day index (0 = Sunday, 1 = Monday, etc.)
        const today = new Date();
        const dayIndex = today.getDay(); // 0 = Sunday
        
        // Map to our chart order (Mon-Sun)
        const chartOrder = [1, 2, 3, 4, 5, 6, 0]; // Monday to Sunday indices
        
        // For demo: Generate random heights for past days, actual for today
        chartBars.forEach((bar, index) => {
            // Get the day of week this bar represents
            const barDayIndex = chartOrder[index];
            
            let height = 0;
            
            if (barDayIndex < dayIndex) {
                // Past day - random data for demo
                height = Math.floor(Math.random() * 100);
            } else if (barDayIndex === dayIndex) {
                // Today - use actual progress
                const todaySeconds = focusTracker.getTodayFocusTime();
                const DAILY_GOAL_SECONDS = 14400; // 4 hours
                height = Math.min((todaySeconds / DAILY_GOAL_SECONDS) * 100, 100);
            }
            // Future days remain at 0
            
            // Set height with animation
            setTimeout(() => {
                bar.style.height = `${height}%`;
                
                // Set color based on height
                if (height < 25) {
                    bar.style.backgroundColor = '#f72585';
                } else if (height < 50) {
                    bar.style.backgroundColor = '#ff9800';
                } else if (height < 75) {
                    bar.style.backgroundColor = '#4cc9f0';
                } else {
                    bar.style.backgroundColor = '#4caf50';
                }
                
                // Add tooltip
                bar.title = `${Math.round(height)}% focus`;
            }, index * 100);
        });
    }

    // Load Subject Distribution Chart
    function loadSubjectChart() {
        const sessions = studyManager.getAllSessions();
        const chartContainer = document.getElementById('subjectChart');
        
        if (!chartContainer) return;
        
        if (sessions.length === 0) {
            chartContainer.innerHTML = `
                <div class="text-center py-5">
                    <i class="fas fa-chart-pie fa-3x text-muted mb-3"></i>
                    <p class="text-muted">No study sessions planned yet</p>
                </div>
            `;
            return;
        }
        
        // Calculate time per subject
        const subjectData = {};
        let totalMinutes = 0;
        
        sessions.forEach(session => {
            const start = new Date(`2000-01-01T${session.startTime}`);
            const end = new Date(`2000-01-01T${session.endTime}`);
            let diff = (end - start) / (1000 * 60); // minutes
            if (diff < 0) diff += 24 * 60;
            
            if (session.subject) {
                subjectData[session.subject] = (subjectData[session.subject] || 0) + diff;
                totalMinutes += diff;
            }
        });
        
        // Sort and generate HTML
        const sortedSubjects = Object.keys(subjectData)
            .sort((a, b) => subjectData[b] - subjectData[a])
            .slice(0, 5);
            
        let html = '<div class="mt-2">';
        const colors = ['bg-primary', 'bg-success', 'bg-info', 'bg-warning', 'bg-danger'];
        
        sortedSubjects.forEach((subject, index) => {
            const minutes = subjectData[subject];
            const percentage = totalMinutes > 0 ? (minutes / totalMinutes) * 100 : 0;
            const hours = (minutes / 60).toFixed(1);
            
            html += `
                <div class="mb-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span class="fw-bold">${subject}</span>
                        <small class="text-muted">${hours} hrs (${Math.round(percentage)}%)</small>
                    </div>
                    <div class="progress" style="height: 10px; border-radius: 5px;">
                        <div class="progress-bar ${colors[index % colors.length]}" role="progressbar" 
                             style="width: ${percentage}%" aria-valuenow="${percentage}" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        chartContainer.innerHTML = html;
    }
    
    // Load Weekly Report
    function loadWeeklyReport() {
        const sessions = studyManager.getAllSessions();
        const focusHistory = focusTracker.getFocusHistory();
        
        // Get current week range (Mon-Sun)
        const d = new Date();
        const currentDay = d.getDay() || 7; // Convert Sun (0) to 7
        d.setHours(0,0,0,0);
        const monday = new Date(d);
        monday.setDate(d.getDate() - currentDay + 1);
        
        const sunday = new Date(monday);
        sunday.setDate(monday.getDate() + 6);
        sunday.setHours(23,59,59,999);
        
        // Update Date Range Display
        const options = { month: 'short', day: 'numeric' };
        const weekRangeEl = document.getElementById('weekRange');
        if (weekRangeEl) {
            weekRangeEl.textContent = `${monday.toLocaleDateString('en-US', options)} - ${sunday.toLocaleDateString('en-US', options)}`;
        }
            
        // Filter sessions for this week
        const weeklySessions = sessions.filter(s => {
            const parts = s.date.split('-');
            const sessionDate = new Date(parts[0], parts[1]-1, parts[2]);
            return sessionDate >= monday && sessionDate <= sunday;
        });
        
        // 1. Tasks Completed
        const completed = weeklySessions.filter(s => s.status === 'completed').length;
        const total = weeklySessions.length;
        const completedEl = document.getElementById('weeklyCompletedTasks');
        if (completedEl) completedEl.textContent = completed;
        
        // 2. Focus Time
        let weeklySeconds = 0;
        // Iterate over history keys to find those within the week
        for (const [dateKey, seconds] of Object.entries(focusHistory)) {
            const historyDate = new Date(dateKey);
            // Simple check if the date falls within the week range
            if (historyDate >= monday && historyDate <= sunday) {
                 weeklySeconds += seconds;
            }
        }
        
        const timeObj = FocusTracker.formatTime(weeklySeconds);
        const focusTimeEl = document.getElementById('weeklyFocusTime');
        if (focusTimeEl) focusTimeEl.textContent = `${timeObj.hours}h ${timeObj.minutes}m`;
        
        // 3. Completion Rate
        const rate = total > 0 ? Math.round((completed / total) * 100) : 0;
        const efficiencyEl = document.getElementById('weeklyEfficiency');
        if (efficiencyEl) efficiencyEl.textContent = `${rate}%`;
        
        // 4. Top Subject
        const subjectCounts = {};
        weeklySessions.forEach(s => {
            if (s.status === 'completed') {
                subjectCounts[s.subject] = (subjectCounts[s.subject] || 0) + 1;
            }
        });
        
        let topSubject = '-';
        let maxCount = 0;
        for (const [subj, count] of Object.entries(subjectCounts)) {
            if (count > maxCount) {
                maxCount = count;
                topSubject = subj;
            }
        }
        const topSubjectEl = document.getElementById('topSubject');
        if (topSubjectEl) topSubjectEl.textContent = topSubject;
    }

    // Add CSS for chart bars
    const style = document.createElement('style');
    style.textContent = `
        .chart-bar {
            width: 40px;
            background-color: #4361ee;
            border-radius: 5px 5px 0 0;
            transition: height 1s ease, background-color 0.5s ease;
            position: relative;
        }
        .chart-bar:hover {
            opacity: 0.8;
        }
        .chart-bar::after {
            content: attr(title);
            position: absolute;
            top: -30px;
            left: 50%;
            transform: translateX(-50%);
            background: #333;
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
            white-space: nowrap;
            opacity: 0;
            transition: opacity 0.3s;
        }
        .chart-bar:hover::after {
            opacity: 1;
        }
        .weekly-chart {
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
        }
    `;
    document.head.appendChild(style);
    
    // Update chart when returning to page
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden) {
            loadDashboardData();
            loadWeeklyChart();
            loadSubjectChart();
            loadWeeklyReport();
        }
    });
});