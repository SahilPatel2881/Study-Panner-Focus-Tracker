// Main Application JavaScript
// Contains shared classes and helper functions

// ============================================
// Helper Functions
// ============================================

// Format date (YYYY-MM-DD to Readable Date)
function formatDate(dateString) {
    if (!dateString) return '';
    const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
    // Handle timezone offset issues by appending time
    const date = new Date(dateString + 'T00:00:00');
    return date.toLocaleDateString('en-US', options);
}

// Format time (HH:MM to 12-hour format)
function formatTime(timeString) {
    if (!timeString) return '';
    // Check if it's HH:MM format
    if (timeString.length === 5) {
        const [hours, minutes] = timeString.split(':');
        let h = parseInt(hours);
        const ampm = h >= 12 ? 'PM' : 'AM';
        h = h % 12;
        h = h ? h : 12; // the hour '0' should be '12'
        return `${h}:${minutes} ${ampm}`;
    }
    return timeString;
}

// Quote Generator for Home Page
const quotes = [
    { text: "The secret of getting ahead is getting started.", author: "Mark Twain" },
    { text: "It always seems impossible until it's done.", author: "Nelson Mandela" },
    { text: "Don't watch the clock; do what it does. Keep going.", author: "Sam Levenson" },
    { text: "Quality is not an act, it is a habit.", author: "Aristotle" },
    { text: "Start where you are. Use what you have. Do what you can.", author: "Arthur Ashe" }
];

function changeQuote() {
    const quoteElement = document.getElementById('dailyQuote');
    const authorElement = document.querySelector('.quote-box .text-muted');
    
    if (quoteElement) {
        const randomIndex = Math.floor(Math.random() * quotes.length);
        quoteElement.textContent = `"${quotes[randomIndex].text}"`;
        if (authorElement) {
            authorElement.textContent = `- ${quotes[randomIndex].author}`;
        }
    }
}

// Initialize quote on load if on index page
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('dailyQuote')) {
        changeQuote();
    }
});

// ============================================
// StudySessions Class - For Study Planner
// ============================================
class StudySessions {
  constructor() {
    this.storageKey = 'studySessions';
    this.sessions = this.loadSessions();
  }

  // Load sessions from localStorage
  loadSessions() {
    const sessions = localStorage.getItem(this.storageKey);
    return sessions ? JSON.parse(sessions) : [];
  }

  // Save sessions to localStorage
  saveSessions() {
    localStorage.setItem(this.storageKey, JSON.stringify(this.sessions));
  }

  // Add a new study session
  addSession(sessionData) {
    const session = {
      id: Date.now(),
      subject: sessionData.subject,
      date: sessionData.date,
      startTime: sessionData.startTime,
      endTime: sessionData.endTime,
      notes: sessionData.notes || '',
      status: 'planned',
      createdAt: new Date().toISOString()
    };
    
    this.sessions.push(session);
    this.saveSessions();
    return session;
  }

  // Get all sessions
  getAllSessions() {
    return this.sessions;
  }

  // Get session by ID
  getSessionById(id) {
    return this.sessions.find(session => session.id === id);
  }

  // Delete a session
  deleteSession(id) {
    this.sessions = this.sessions.filter(session => session.id !== id);
    this.saveSessions();
    return true;
  }

  // Mark session as complete
  markSessionComplete(id) {
    const index = this.sessions.findIndex(session => session.id === id);
    if (index !== -1) {
      this.sessions[index].status = 'completed';
      this.saveSessions();
      return true;
    }
    return false;
  }

  // Update a session
  updateSession(id, updatedData) {
    const index = this.sessions.findIndex(session => session.id === id);
    if (index !== -1) {
      this.sessions[index] = { ...this.sessions[index], ...updatedData };
      this.saveSessions();
      return this.sessions[index];
    }
    return null;
  }

  // Get sessions by date
  getSessionsByDate(date) {
    return this.sessions.filter(session => session.date === date);
  }

  // Get sessions by subject
  getSessionsBySubject(subject) {
    return this.sessions.filter(session => 
      session.subject.toLowerCase().includes(subject.toLowerCase())
    );
  }

  // Clear all sessions
  clearAllSessions() {
    this.sessions = [];
    this.saveSessions();
  }

  // Get total number of sessions
  getTotalSessions() {
    return this.sessions.length;
  }

  // Get unique subjects studied
  getUniqueSubjects() {
    const subjects = new Set();
    this.sessions.forEach(session => {
      subjects.add(session.subject);
    });
    return Array.from(subjects);
  }
}

// ============================================
// FocusTracker Class - For Focus Timer
// ============================================
class FocusTracker {
  constructor() {
    this.storageKey = 'focusTracker';
    this.data = this.loadData();
  }

  // Load focus data from localStorage
  loadData() {
    const data = localStorage.getItem(this.storageKey);
    if (data) {
      return JSON.parse(data);
    }
    // Initialize with default data
    return {
      totalFocusTime: 0,
      focusHistory: {}
    };
  }

  // Save focus data to localStorage
  saveData() {
    localStorage.setItem(this.storageKey, JSON.stringify(this.data));
  }

  // Get today's date key
  getTodayKey() {
    return new Date().toISOString().split('T')[0];
  }

  // Get today's focus time in seconds
  getTodayFocusTime() {
    const today = this.getTodayKey();
    return this.data.focusHistory[today] || 0;
  }

  // Get total focus time in seconds
  getTotalFocusTime() {
    return this.data.totalFocusTime || 0;
  }

  // Start timer (records start time)
  startTimer() {
    const today = this.getTodayKey();
    if (!this.data.focusHistory[today]) {
      this.data.focusHistory[today] = 0;
    }
    // Store start time in sessionStorage for persistence across page refreshes
    sessionStorage.setItem('focusTimerStart', Date.now().toString());
    sessionStorage.setItem('focusTimerRunning', 'true');
    return true;
  }

  // Stop timer (calculates elapsed time and saves)
  stopTimer() {
    const startTime = sessionStorage.getItem('focusTimerStart');
    const isRunning = sessionStorage.getItem('focusTimerRunning');
    
    if (!startTime || isRunning !== 'true') {
      return 0;
    }
    
    const elapsed = Math.floor((Date.now() - parseInt(startTime)) / 1000);
    
    // Add to today's focus time
    const today = this.getTodayKey();
    if (!this.data.focusHistory[today]) {
      this.data.focusHistory[today] = 0;
    }
    this.data.focusHistory[today] += elapsed;
    
    // Add to total focus time
    this.data.totalFocusTime += elapsed;
    
    // Save to localStorage
    this.saveData();
    
    // Clear session storage
    sessionStorage.removeItem('focusTimerStart');
    sessionStorage.removeItem('focusTimerRunning');
    
    return elapsed;
  }

  // Add focus time directly (in seconds)
  addFocusTime(seconds) {
    const today = this.getTodayKey();
    
    if (!this.data.focusHistory[today]) {
      this.data.focusHistory[today] = 0;
    }
    
    this.data.focusHistory[today] += seconds;
    this.data.totalFocusTime += seconds;
    
    this.saveData();
  }

  // Reset today's focus time
  resetTodayFocus() {
    const today = this.getTodayKey();
    const todayTime = this.data.focusHistory[today] || 0;
    
    // Subtract from total
    this.data.totalFocusTime -= todayTime;
    if (this.data.totalFocusTime < 0) {
      this.data.totalFocusTime = 0;
    }
    
    // Reset today's time
    this.data.focusHistory[today] = 0;
    
    this.saveData();
  }

  // Reset all focus data
  resetAllFocus() {
    this.data = {
      totalFocusTime: 0,
      focusHistory: {}
    };
    this.saveData();
  }

  // Get focus time for a specific date
  getFocusTimeForDate(date) {
    return this.data.focusHistory[date] || 0;
  }

  // Get focus history
  getFocusHistory() {
    return this.data.focusHistory;
  }

  // Static method to format time
  static formatTime(totalSeconds) {
    const seconds = totalSeconds % 60;
    const minutes = Math.floor(totalSeconds / 60) % 60;
    const hours = Math.floor(totalSeconds / 3600);
    
    return {
      hours: hours.toString().padStart(2, '0'),
      minutes: minutes.toString().padStart(2, '0'),
      seconds: seconds.toString().padStart(2, '0'),
      formatted: `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
    };
  }
}
