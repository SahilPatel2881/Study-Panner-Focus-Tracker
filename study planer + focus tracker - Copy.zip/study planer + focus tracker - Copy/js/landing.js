document.addEventListener('DOMContentLoaded', function() {
    const startBtn = document.getElementById('startBtn');
    
    if (startBtn) {
        startBtn.addEventListener('click', function() {
            // Check if already logged in
            const loggedIn = localStorage.getItem("loggedIn");
            if (loggedIn === "true") {
                window.location.href = "index.html";
            } else {
                window.location.href = "login.html";
            }
        });
    }
});