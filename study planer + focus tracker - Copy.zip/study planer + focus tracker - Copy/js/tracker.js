// Focus Tracker Page JavaScript
// FSD-1 Syllabus: Timer Functions, DOM Manipulation, Events, LocalStorage

document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const timerDisplay = document.getElementById('timerDisplay');
    const startBtn = document.getElementById('startBtn');
    const pauseBtn = document.getElementById('pauseBtn');
    const resetBtn = document.getElementById('resetBtn');
    const resetTodayBtn = document.getElementById('resetTodayBtn');
    const timerStatus = document.getElementById('timerStatus');
    const todayFocusTime = document.getElementById('todayFocusTime');
    const progressPercentage = document.getElementById('progressPercentage');
    const focusProgressBar = document.getElementById('focusProgressBar');
    const sessionDuration = document.getElementById('sessionDuration');
    const plannedSessionSelect = document.getElementById('plannedSession');
    
    // Initialize FocusTracker
    const focusTracker = new FocusTracker();
    const studyManager = new StudySessions();
    let currentSessionId = null;
    
    // Timer variables
    let timerRunning = false;
    let timerSeconds = 0;
    let timerInterval = null;
    
    // Daily goal in seconds (4 hours = 14400 seconds)
    const DAILY_GOAL_SECONDS = 14400;
    
    // Update display initially
    updateDisplay();
    updateProgress();
    loadPlannedSessions();
    
    // Request notification permission
    if ("Notification" in window && Notification.permission !== "granted") {
        Notification.requestPermission();
    }
    
    // Event Listeners
    startBtn.addEventListener('click', startTimer);
    pauseBtn.addEventListener('click', pauseTimer);
    resetBtn.addEventListener('click', resetTimer);
    resetTodayBtn.addEventListener('click', resetTodayFocus);
    
    // Planned Session Selection
    if (plannedSessionSelect) {
        plannedSessionSelect.addEventListener('change', function() {
            const sessionId = parseInt(this.value);
            if (sessionId) {
                const session = studyManager.getSessionById(sessionId);
                if (session) {
                    // Calculate duration in seconds
                    const start = new Date(`2000-01-01T${session.startTime}`);
                    const end = new Date(`2000-01-01T${session.endTime}`);
                    let diffSeconds = (end - start) / 1000;
                    if (diffSeconds < 0) diffSeconds += 24 * 3600;
                    
                    // Add custom option to duration selector
                    const oldCustom = sessionDuration.querySelector('option[data-custom="true"]');
                    if (oldCustom) oldCustom.remove();
                    
                    const option = document.createElement('option');
                    option.value = diffSeconds;
                    option.textContent = `Planned: ${session.subject} (${Math.round(diffSeconds/60)}m)`;
                    option.selected = true;
                    option.setAttribute('data-custom', 'true');
                    sessionDuration.appendChild(option);
                    
                    currentSessionId = sessionId;
                    
                    // Update status
                    timerStatus.textContent = `Ready to focus on: ${session.subject}`;
                    timerStatus.className = 'text-primary fw-bold';
                }
            } else {
                currentSessionId = null;
                const oldCustom = sessionDuration.querySelector('option[data-custom="true"]');
                if (oldCustom) {
                    oldCustom.remove();
                    sessionDuration.value = "1500"; // Default back to 25m
                }
            }
        });
    }

    // Start Timer Function
    function startTimer() {
        if (!timerRunning) {
            // Start the tracker
            focusTracker.startTimer();
            
            // Update UI
            timerRunning = true;
            startBtn.disabled = true;
            pauseBtn.disabled = false;
            timerStatus.textContent = 'Focus session in progress...';
            timerStatus.className = 'text-success fw-bold';
            if (sessionDuration) sessionDuration.disabled = true;
            if (plannedSessionSelect) plannedSessionSelect.disabled = true;
            
            // Start visual timer
            timerInterval = setInterval(() => {
                timerSeconds++;
                updateTimerDisplay();
                checkSessionGoal();
            }, 1000);
        }
    }
    
    // Pause Timer Function
    function pauseTimer() {
        if (timerRunning) {
            // Stop the tracker
            const elapsed = focusTracker.stopTimer();
            
            // Update UI
            timerRunning = false;
            startBtn.disabled = false;
            pauseBtn.disabled = true;
            timerStatus.textContent = `Focus session paused. You focused for ${formatSeconds(elapsed)}.`;
            timerStatus.className = 'text-warning fw-bold';
            if (sessionDuration) sessionDuration.disabled = false;
            if (plannedSessionSelect) plannedSessionSelect.disabled = false;
            
            // Stop visual timer
            clearInterval(timerInterval);
            
            // Update progress
            updateProgress();
        }
    }
    
    // Reset Timer Function
    function resetTimer() {
        if (timerRunning) {
            clearInterval(timerInterval);
            timerRunning = false;
        }
        
        timerSeconds = 0;
        updateTimerDisplay();
        
        startBtn.disabled = false;
        pauseBtn.disabled = true;
        timerStatus.textContent = 'Timer reset. Ready to start a new focus session.';
        timerStatus.className = 'text-info';
        if (sessionDuration) sessionDuration.disabled = false;
        if (plannedSessionSelect) plannedSessionSelect.disabled = false;
    }
    
    // Reset Today's Focus
    function resetTodayFocus() {
        if (confirm('Are you sure you want to reset today\'s focus time? This cannot be undone.')) {
            focusTracker.resetTodayFocus();
            updateDisplay();
            updateProgress();
            timerStatus.textContent = 'Today\'s focus time has been reset.';
            timerStatus.className = 'text-info';
        }
    }
    
    // Check if session goal is reached
    function checkSessionGoal() {
        const goal = parseInt(sessionDuration.value);
        if (goal > 0 && timerSeconds === goal) {
            // Goal reached
            notifyUser("Session Complete!", "You have reached your study goal.");
            playNotificationSound();
            
            // Mark planned session as complete
            if (currentSessionId) {
                studyManager.markSessionComplete(currentSessionId);
                loadPlannedSessions(); // Refresh list
            }
            
            // Pause timer automatically
            pauseTimer();
            
            // Update status
            timerStatus.textContent = currentSessionId 
                ? "Session goal reached! Task marked as completed." 
                : "Session goal reached! Take a break.";
            timerStatus.className = "text-success fw-bold";
            currentSessionId = null; // Reset current session
        }
    }

    // Send Notification
    function notifyUser(title, body) {
        if (!("Notification" in window)) {
            alert(body);
        } else if (Notification.permission === "granted") {
            new Notification(title, { body: body, icon: 'img/icon.png' });
        } else if (Notification.permission !== "denied") {
            Notification.requestPermission().then(permission => {
                if (permission === "granted") {
                    new Notification(title, { body: body });
                }
            });
        }
    }

    // Play Notification Sound (Simple Beep)
    function playNotificationSound() {
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (AudioContext) {
                const ctx = new AudioContext();
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.type = 'sine';
                osc.frequency.value = 880; // A5
                gain.gain.value = 0.1;
                osc.start();
                setTimeout(() => osc.stop(), 500);
            }
        } catch (e) {
            console.error("Audio context error", e);
        }
    }

    // Load Planned Sessions
    function loadPlannedSessions() {
        if (!plannedSessionSelect) return;
        
        const today = new Date().toISOString().split('T')[0];
        const sessions = studyManager.getSessionsByDate(today);
        
        // Keep first option
        while (plannedSessionSelect.options.length > 1) {
            plannedSessionSelect.remove(1);
        }
        
        sessions.forEach(session => {
            const option = document.createElement('option');
            option.value = session.id;
            const isCompleted = session.status === 'completed';
            option.textContent = `${session.subject} (${formatTime(session.startTime)} - ${formatTime(session.endTime)})${isCompleted ? ' ✓' : ''}`;
            if (isCompleted) option.disabled = true;
            plannedSessionSelect.appendChild(option);
        });
    }

    // Update Timer Display
    function updateTimerDisplay() {
        const formatted = FocusTracker.formatTime(timerSeconds).formatted;
        timerDisplay.textContent = formatted;
    }
    
    // Update All Displays
    function updateDisplay() {
        // Update today's focus time
        const todaySeconds = focusTracker.getTodayFocusTime();
        todayFocusTime.textContent = FocusTracker.formatTime(todaySeconds).formatted;
        
        // Update total focus time in status if needed
        const totalSeconds = focusTracker.getTotalFocusTime();
        document.title = `Focus Tracker (${FocusTracker.formatTime(todaySeconds).hours}:${FocusTracker.formatTime(todaySeconds).minutes}) - StudyFocus`;
    }
    
    // Update Progress Bar
    function updateProgress() {
        const todaySeconds = focusTracker.getTodayFocusTime();
        const progress = Math.min((todaySeconds / DAILY_GOAL_SECONDS) * 100, 100);
        
        focusProgressBar.style.width = `${progress}%`;
        progressPercentage.textContent = `${Math.round(progress)}%`;
        
        // Change color based on progress
        if (progress < 25) {
            focusProgressBar.style.backgroundColor = '#f72585'; // Red
        } else if (progress < 50) {
            focusProgressBar.style.backgroundColor = '#ff9800'; // Orange
        } else if (progress < 75) {
            focusProgressBar.style.backgroundColor = '#4cc9f0'; // Blue
        } else {
            focusProgressBar.style.backgroundColor = '#4caf50'; // Green
        }
    }
    
    // Format seconds to readable time
    function formatSeconds(seconds) {
        const time = FocusTracker.formatTime(seconds);
        
        if (time.hours > 0) {
            return `${time.hours}h ${time.minutes}m ${time.seconds}s`;
        } else if (time.minutes > 0) {
            return `${time.minutes}m ${time.seconds}s`;
        } else {
            return `${time.seconds}s`;
        }
    }
    
    // Update display every minute even when timer not running
    // (to catch changes from other tabs)
    setInterval(() => {
        if (!timerRunning) {
            updateDisplay();
            updateProgress();
        }
    }, 60000);
    
    // Update page title with timer when running
    setInterval(() => {
        if (timerRunning) {
            const formatted = FocusTracker.formatTime(timerSeconds);
            document.title = `Focusing (${formatted.hours}:${formatted.minutes}:${formatted.seconds}) - StudyFocus`;
        }
    }, 1000);
    
    // Handle page visibility change
    document.addEventListener('visibilitychange', function() {
        if (document.hidden && timerRunning) {
            // Page is hidden, warn user
            console.log('Page is hidden - timer continues in background');
        }
    });
    
    // Warn before leaving page when timer is running
    window.addEventListener('beforeunload', function(e) {
        if (timerRunning) {
            e.preventDefault();
            e.returnValue = 'You have a focus timer running. Are you sure you want to leave?';
            return e.returnValue;
        }
    });
});

// Make functions available globally if needed
function startTimer() {
    // This allows the HTML onclick to work if needed
    const startBtn = document.getElementById('startBtn');
    if (startBtn) startBtn.click();
}

function pauseTimer() {
    const pauseBtn = document.getElementById('pauseBtn');
    if (pauseBtn) pauseBtn.click();
}

function resetTimer() {
    const resetBtn = document.getElementById('resetBtn');
    if (resetBtn) resetBtn.click();
}