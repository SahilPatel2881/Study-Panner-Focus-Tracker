// Study Planner Page JavaScript
// FSD-1 Syllabus: DOM Manipulation, Events, Form Handling, LocalStorage

// Global StudySessions instance
let studyManager;

document.addEventListener('DOMContentLoaded', function() {
    // Initialize StudySessions manager
    studyManager = new StudySessions();
    
    // DOM Elements
    const studyForm = document.getElementById('studyForm');
    const sessionsList = document.getElementById('sessionsList');
    const noSessionsMessage = document.getElementById('noSessionsMessage');
    
    // Set minimum date to today
    const dateInput = document.getElementById('date');
    const today = new Date().toISOString().split('T')[0];
    dateInput.min = today;
    dateInput.value = today;
    
    // Set default times (next hour)
    const now = new Date();
    const nextHour = new Date(now.getTime() + 60 * 60 * 1000);
    
    const startTimeInput = document.getElementById('startTime');
    const endTimeInput = document.getElementById('endTime');
    
    // Format time to HH:MM
    function formatTimeForInput(date) {
        return date.toTimeString().slice(0, 5);
    }
    
    startTimeInput.value = formatTimeForInput(now);
    endTimeInput.value = formatTimeForInput(nextHour);
    
    // Load existing sessions
    loadSessions();
    
    // Form Submission Event
    studyForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate form
        if (!validateForm('studyForm')) {
            return;
        }
        
        // Validate time
        if (startTimeInput.value >= endTimeInput.value) {
            alert('End time must be after start time!');
            endTimeInput.focus();
            return;
        }
        
        // Get form values
        const sessionData = {
            subject: document.getElementById('subject').value.trim(),
            date: dateInput.value,
            startTime: startTimeInput.value,
            endTime: endTimeInput.value,
            notes: document.getElementById('notes').value.trim()
        };
        
        // Add session
        studyManager.addSession(sessionData);
        
        // Clear form (except date and times)
        studyForm.reset();
        dateInput.value = today;
        startTimeInput.value = formatTimeForInput(now);
        endTimeInput.value = formatTimeForInput(nextHour);
        
        // Reload sessions
        loadSessions();
        
        // Show success message
        showAlert('Study session added successfully!', 'success');
    });
    
    // Load and display sessions
    function loadSessions() {
        const sessions = studyManager.getAllSessions();
        
        // Clear current list
        sessionsList.innerHTML = '';
        
        if (sessions.length === 0) {
            // Show no sessions message
            const emptyMessage = document.createElement('div');
            emptyMessage.className = 'text-center py-5';
            emptyMessage.innerHTML = `
                <i class="fas fa-calendar-plus fa-3x text-muted mb-3"></i>
                <h4>No study sessions planned yet</h4>
                <p class="text-muted">Add your first study session using the form above!</p>
            `;
            sessionsList.appendChild(emptyMessage);
            return;
        }
        
        // Sort sessions by date and time (newest first)
        sessions.sort((a, b) => {
            const dateA = new Date(a.date + 'T' + a.startTime);
            const dateB = new Date(b.date + 'T' + b.startTime);
            return dateB - dateA;
        });
        
        // Create session elements
        sessions.forEach(session => {
            const sessionElement = createSessionElement(session);
            sessionsList.appendChild(sessionElement);
        });
    }
    
    // Create session HTML element
    function createSessionElement(session) {
        const div = document.createElement('div');
        div.className = 'table-row';
        div.id = `session-${session.id}`;
        
        // Format date
        const formattedDate = formatDate(session.date);
        
        // Format time
        const formattedTime = `${formatTime(session.startTime)} - ${formatTime(session.endTime)}`;
        
        div.innerHTML = `
            <div class="row align-items-center">
                <div class="col-md-3">
                    <strong>${session.subject}</strong>
                </div>
                <div class="col-md-2">
                    ${formattedDate}
                </div>
                <div class="col-md-2">
                    ${formattedTime}
                </div>
                <div class="col-md-3">
                    ${session.notes || '<span class="text-muted">No notes</span>'}
                </div>
                <div class="col-md-2">
                    <button class="btn btn-sm btn-danger delete-btn" 
                            onclick="deleteSession(${session.id})"
                            data-bs-toggle="tooltip" 
                            title="Delete this session">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        `;
        
        return div;
    }
    
    // Show alert message
    function showAlert(message, type = 'info') {
        // Remove existing alerts
        const existingAlert = document.querySelector('.alert');
        if (existingAlert) {
            existingAlert.remove();
        }
        
        // Create alert element
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        // Insert after form
        const formContainer = document.querySelector('.form-container');
        formContainer.parentNode.insertBefore(alertDiv, formContainer);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }
});

// Helper function to validate form
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;
    
    const inputs = form.querySelectorAll('input[required], textarea[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            isValid = false;
            input.classList.add('is-invalid');
        } else {
            input.classList.remove('is-invalid');
        }
    });
    
    return isValid;
}

// Delete session function (needs to be global for onclick)
function deleteSession(sessionId) {
    if (confirm('Are you sure you want to delete this study session?')) {
        // Use global studyManager instance
        if (studyManager) {
            studyManager.deleteSession(sessionId);
            
            // Remove from DOM
            const sessionElement = document.getElementById(`session-${sessionId}`);
            if (sessionElement) {
                sessionElement.remove();
            }
            
            // Reload sessions to check if empty
            const sessions = studyManager.getAllSessions();
            const sessionsList = document.getElementById('sessionsList');
            
            if (sessions.length === 0) {
                const noSessionsMessage = document.createElement('div');
                noSessionsMessage.className = 'text-center py-5';
                noSessionsMessage.id = 'noSessionsMessage';
                noSessionsMessage.innerHTML = `
                    <i class="fas fa-calendar-plus fa-3x text-muted mb-3"></i>
                    <h4>No study sessions planned yet</h4>
                    <p class="text-muted">Add your first study session using the form above!</p>
                `;
                sessionsList.appendChild(noSessionsMessage);
            }
            
            // Show success message
            showAlert('Study session deleted successfully!', 'success');
        } else {
            alert('Error: Study manager not initialized');
        }
    }
}

// Helper function to show alert from global scope
function showAlert(message, type = 'info') {
    const existingAlert = document.querySelector('.alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    const formContainer = document.querySelector('.form-container');
    if (formContainer && formContainer.parentNode) {
        formContainer.parentNode.insertBefore(alertDiv, formContainer);
        
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }
}