// Sign Up
function signup() {
  const username = document.getElementById("su-username").value;
  const password = document.getElementById("su-password").value;

  if (!username || !password) {
    document.getElementById("signupMsg").innerText = "All fields required";
    return;
  }

  if (password.length < 6) {
    document.getElementById("signupMsg").innerText = "Password must be at least 6 characters";
    return;
  }

  const users = JSON.parse(localStorage.getItem("users")) || [];

  const userExists = users.find(u => u.username === username);
  if (userExists) {
    document.getElementById("signupMsg").innerText = "User already exists";
    return;
  }

  users.push({ username, password });
  localStorage.setItem("users", JSON.stringify(users));

  document.getElementById("signupMsg").innerText = "Signup successful! Redirecting to login...";

  setTimeout(() => {
    window.location.href = "login.html";
  }, 1000);
}

// Login
function login() {
  const username = document.getElementById("li-username").value;
  const password = document.getElementById("li-password").value;

  const users = JSON.parse(localStorage.getItem("users")) || [];
  const validUser = users.find(u => u.username === username && u.password === password);

  if (!validUser) {
    document.getElementById("loginMsg").innerText = "Invalid credentials";
    return;
  }

  localStorage.setItem("loggedIn", "true");
  localStorage.setItem("currentUser", username);

  window.location.href = "index.html";
}

// Protect main app (index.html)
(function protect() {
  const path = window.location.pathname;
  if (path.includes("index.html") || path.includes("planner.html") || path.includes("tracker.html") || path.includes("dashboard.html") || path.includes("profile.html")) {
    const loggedIn = localStorage.getItem("loggedIn");
    if (loggedIn !== "true") {
      window.location.href = "login.html";
    }
  }
})();

// Logout with custom confirmation modal
function confirmLogout() {
  // Check if modal exists, if not create it
  if (!document.getElementById('logoutModal')) {
    createLogoutModal();
  }
  // Show modal
  document.getElementById('logoutModal').style.display = 'flex';
}

function createLogoutModal() {
  const modal = document.createElement('div');
  modal.id = 'logoutModal';
  modal.className = 'custom-modal';
  
  modal.innerHTML = `
    <div class="modal-content">
      <div class="mb-4">
        <i class="fas fa-sign-out-alt fa-4x text-danger"></i>
      </div>
      <h3 class="mb-3">Log Out?</h3>
      <p class="text-muted mb-4">Are you sure you want to end your session?</p>
      <div class="d-flex justify-content-center gap-3">
        <button onclick="closeLogoutModal()" class="btn btn-light btn-lg px-4">Cancel</button>
        <button onclick="performLogout()" class="btn btn-danger btn-lg px-4">Log Out</button>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
}

function closeLogoutModal() {
  const modal = document.getElementById('logoutModal');
  if (modal) modal.style.display = 'none';
}

function performLogout() {
  localStorage.removeItem("loggedIn");
  localStorage.removeItem("currentUser");

  window.location.href = "login.html";
}

// Load Profile Data
function loadProfile() {
  const currentUser = localStorage.getItem("currentUser");
  const usernameField = document.getElementById("current-username");
  if (usernameField && currentUser) {
    usernameField.value = currentUser;
  }
}

// Update Username
function updateUsername() {
  const newUsername = document.getElementById("new-username").value;
  const currentUser = localStorage.getItem("currentUser");
  const msg = document.getElementById("profileMsg");
  
  if (!newUsername) return;
  
  const users = JSON.parse(localStorage.getItem("users")) || [];
  
  if (users.find(u => u.username === newUsername)) {
    msg.innerHTML = '<div class="alert alert-danger">Username already taken</div>';
    return;
  }
  
  const userIndex = users.findIndex(u => u.username === currentUser);
  if (userIndex !== -1) {
    users[userIndex].username = newUsername;
    localStorage.setItem("users", JSON.stringify(users));
    localStorage.setItem("currentUser", newUsername);
    
    document.getElementById("current-username").value = newUsername;
    document.getElementById("new-username").value = "";
    msg.innerHTML = '<div class="alert alert-success">Username updated successfully</div>';
  }
}

// Update Password
function updatePassword() {
  const currentPass = document.getElementById("current-password").value;
  const newPass = document.getElementById("new-password").value;
  const currentUser = localStorage.getItem("currentUser");
  const msg = document.getElementById("profileMsg");
  
  if (newPass.length < 6) {
    msg.innerHTML = '<div class="alert alert-danger">Password must be at least 6 characters</div>';
    return;
  }
  
  const users = JSON.parse(localStorage.getItem("users")) || [];
  const userIndex = users.findIndex(u => u.username === currentUser);
  
  if (userIndex !== -1) {
    if (users[userIndex].password !== currentPass) {
      msg.innerHTML = '<div class="alert alert-danger">Incorrect current password</div>';
      return;
    }
    
    users[userIndex].password = newPass;
    localStorage.setItem("users", JSON.stringify(users));
    
    document.getElementById("current-password").value = "";
    document.getElementById("new-password").value = "";
    msg.innerHTML = '<div class="alert alert-success">Password updated successfully</div>';
  }
}

// Initialize Dark Mode
function initDarkMode() {
  const darkModeSwitch = document.getElementById('darkModeSwitch');
  const body = document.body;
  
  // Check local storage and apply mode
  if (localStorage.getItem('darkMode') === 'enabled') {
    body.classList.add('dark-mode');
    if (darkModeSwitch) darkModeSwitch.checked = true;
  }
  
  // Handle toggle switch changes
  if (darkModeSwitch) {
    darkModeSwitch.addEventListener('change', function() {
      if (this.checked) {
        body.classList.add('dark-mode');
        localStorage.setItem('darkMode', 'enabled');
      } else {
        body.classList.remove('dark-mode');
        localStorage.setItem('darkMode', 'disabled');
      }
    });
  }
}

// Run on load
document.addEventListener('DOMContentLoaded', initDarkMode);
